 # mainframe=Frame(self.root,bd=12,relief=RIDGE,padx=15,bg=bg_color)
        # mainframe.place(x=0,y=90,width=1600,height=730)