<?php

include('php/dbconn.php');

$sql="Select count(*) from inquery";
$query=mysqli_query($db,$sql);
$fetch=mysqli_fetch_array($query);

?>

 <div id="skin-select">
        <div id="logo">
            <h1>VSS
            </h1>
        </div>

        <a id="toggle">
            <span class="entypo-menu"></span>
        </a>
        
        <div class="skin-part">
            <div id="tree-wrap">
                <div class="side-bar">
                    <ul class="topnav menu-left-nest">
                        <li>
                            <a href="#" style="border-left:0px solid!important;" class="title-menu-left">

                                <span class="widget-menu"></span>
                                <i data-toggle="tooltip" class="entypo-cog pull-right config-wrap"></i>

                            </a>
                        </li>
                           <li>
                            <a class="tooltip-tip ajax-load" href="../index_1" title="Log out">
                                <i class="icon-feed"></i>
                                <span>Home</span>
                            </a>
                        </li>
                        
                        <li class="hide1">
                            <a class="tooltip-tip ajax-load" href="#" title="Employee">
                                <i class="icon-document-edit"></i>
                                <span>Employee</span>
                            </a>
                            <ul>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/emp_insert_0" title="Add"><i class="entypo-doc-text"></i><span>Add</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/emp_display_0" title="View"><i class="entypo-doc-text"></i><span>View</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/emp_edit1_0" title="Edit"><i class="entypo-doc-text"></i><span>Edit</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/emp_delete1_0" title="Delete"><i class="entypo-doc-text"></i><span>Delete</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="hide1">
                            <a class="tooltip-tip ajax-load" href="#" title="Department">
                                <i class="icon-document-edit"></i>
                                <span>Department</span>

                            </a>
                            <ul>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/department_0" title="Add"><i class="entypo-doc-text"></i><span>Add</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/department_display_0" title="View"><i class="entypo-doc-text"></i><span>View</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/department_delete_0" title="Delete"><i class="entypo-doc-text"></i><span>Delete</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="hide1">
                            <a class="tooltip-tip ajax-load" href="#" title="Admin User">
                                <i class="icon-document-edit"></i>
                                <span>Admin User</span>

                            </a>
                            <ul>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/admin_user_0" title="Add"><i class="entypo-doc-text"></i><span>Add</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/admin_display_0" title="View"><i class="entypo-doc-text"></i><span>View</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="../php/admin_delete_0" title="Delete"><i class="entypo-doc-text"></i><span>Delete</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="hide1">
                            <a class="tooltip-tip ajax-load" href="../php/report_0" title="Report">
                                <i class="icon-camera"></i>
                                <span>Report</span>
                            </a>
                        </li>
                        <li>
                            <a class="tooltip-tip ajax-load" href="../php/logout?log" title="Log out">
                                <i class="icon-feed"></i>
                                <span>Log Out</span>
                            </a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
