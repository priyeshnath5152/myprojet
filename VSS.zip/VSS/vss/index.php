<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>VSS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description">
    <meta name="author">

    <!-- Le styles -->
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>

   <!--  <link rel="stylesheet" href="assets/css/style.css"> -->
    <link rel="stylesheet" href="assets/css/loader-style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/signin.css">

    <link rel="shortcut icon" href="assets/ico/minus.png">
</head>

<body>
    <!-- Preloader -->
<form action="php/login_1" method="post">
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>
    <div class="container">

        <div class="" id="login-wrapper">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div id="logo-login">
                        <h1>Visitor Security System
                        </h1>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="account-box">

                        <form role="form">
                            <div class="form-group">
                                <label for="inputUsernameEmail">Username</label>
                                <input type="text" name="username" id="inputUsernameEmail" class="form-control" required autocomplete="off">
                            </div>
                            <div class="form-group">
                                <a href="html/forget_pass2.html" class="pull-right label-forgot">Forgot password?</a>
                                <label for="inputPassword">Password</label>
                                <input type="password" name="password" id="inputPassword" class="form-control" required autocomplete="off">
                            </div>
                            <div class="form-group">
                            <label>Type</label>
                                <select name="user" class="form-control" required>
                                    <option >Select User Type </option>
                                    <option value="admin">Admin</option>
                                    <option value="guard">Guard</option>
                                    
                                </select>
                            </div>
                        
                            <button class="btn btn btn-primary pull-left" type="submit">
                                Log In
                            </button>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>



    </div>
    <div id="test1" class="gmap3"></div>



    <!--  END OF PAPER WRAP -->




    <!-- MAIN EFFECT -->
    <script type="text/javascript" src="assets/js/preloader.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/app.js"></script>
    <script type="text/javascript" src="assets/js/load.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
</form>
 
  </body>

</html>
