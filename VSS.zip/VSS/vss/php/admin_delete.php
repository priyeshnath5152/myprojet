<head>
<title>Admin User</title>
<style>
	body
	{
		text-align: center;
		background-size: cover;
		background-repeat: no-repeat;
	}

	table
	{

		border-collapse: collapse;
		border:none;
	}
	td
	{
		text-align: center;
		height: 50px;
		width: 150px;
		color: white;
	}
	img
	{
		border: none;
	}
	th
	{
		font-family: verdana;
		font-size: 23px;
		color: skyblue;
	}

</style>
</head>
<body>
<?php
include('dbconn.php');

$sql="Select * from login_user";
$query=mysqli_query($db,$sql);
echo "<table align='center' border='1'>";
	echo "<tr>";
		echo "<th> Name</th>";
		echo "<th> Username</th>";
		echo "<th> Gender</th>";
		echo "<th> Phone</th>";
		echo "<th> Password</th>";
		echo "<th> User Type</th>";
		echo "<th> Image</th>";
		echo "<th> Delete</th>";
	echo "</tr>";


while ($fetch=mysqli_fetch_array($query))
 {
	echo "<tr>";
		echo "<td> $fetch[name]</td>";
		echo "<td> $fetch[username]</td>";
		echo "<td> $fetch[gender]</td>";
		echo "<td> $fetch[phone]</td>";
		echo "<td> $fetch[password]</td>";
		echo "<td> $fetch[user]</td>";
		echo "<td> <img src='../images/$fetch[image]' width='100' height='100'</td>";
		echo "<td> <a href='admin_delete_1?id=$fetch[0]'>Delete</a></td>";
	echo "</tr>";
}
echo "</table>";
echo "<br><br>";
?>
<form action="../index_1">
<!--
<input type="button" id="p3" value="Print" onclick="print12()">
<input type="submit" value="Back"> -->
</form>
<script type="text/javascript">
	function print12()
	{
		w=document.getElementById('p3');
		w.style.display='none';
		window.print();
		w.style.display='block';

	}
</script>

</body>