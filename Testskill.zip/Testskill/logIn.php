<?php
session_start();
require_once('connection.php');
if(isset($_POST['login'])){
$email = $_POST['email'];
$password = $_POST['password'];
$sql = "select * from student where email='$email' and password='$password'";
$result = mysqli_query($conn, $sql);
$num = mysqli_num_rows($result);
if ($num == 1) {
$_SESSION['is_login'] = true;
$_SESSION['email'] = $email;
header('location:home.php');
}else {
header('location:login.php');
}

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>login page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<h1 class="text-muted ">LogIn here!</h1>
		<form class="col-8" action="" method="POST" autocomplete="on">
	 	<div class="form-group">
	    <label>Email</label>
	    <input type="text" class="form-control" name="email" placeholder="Enter email">
	    <small class="form-text text-muted">We'll never share your email with anyone else.</small>
		</div>
	 	<div class="form-group">
	    <label>Password</label>
	    <input type="password" name="password" class="form-control"  placeholder="Password">
	 	</div>
	 	<span>Create account?/<a href="register.php"> Register here</a></span><br>
  		<button type="submit" name="login" class="btn btn-success">Login</button>
		</form>
	</div>
</body>
</html>