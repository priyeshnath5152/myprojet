<?php
session_start();
require_once('connection.php');

if(isset($_POST['register'])) {
$name = $_POST['name'];
$middlename = $_POST['middlename'];
$sname = $_POST['sname'];
$gender = $_POST['gender'];
$password = $_POST['password'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$DOB = $_POST['DOB'];
$qualification = $_POST['qualification'];
$university = $_POST['university'];
$address = $_POST['address'];
$image=$_FILES['image']['name'];
$temp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($temp_name,"Images/".$image);

	$sql = "INSERT into student(name,middlename,sname,gender,mobile,email,password,DOB,qualification,University,Address,image)
	values('$name','$middlename','$sname','$gender','$mobile','$email','$password','$DOB','$qualification','$university','$address','$image')";
	$query = mysqli_query($conn,$sql);
	if($query) {
		echo"<script>alert('Registeration successfully completed'); 
		     	location.href='logIn.php'; 
					</script>";
	}else{
		echo "Error";
	}
	
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>register page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container border mb-5">
		<h1 class="text-muted ">Register here!</h1>
		<form class="col-8 col-sm-8 col-lg-8" action="register.php" method="POST" enctype="multipart/form-data">
	 	<div class="form-group">
	    <label>First Name</label>
	    <input type="text" class="form-control" name="name" placeholder="Enter name" required>
	    <label>Middle Name</label>
	    <input type="text" class="form-control" name="middlename" placeholder="Enter middle name" required>
	    <label>Last name</label>
	    <input type="text" class="form-control" name="sname" placeholder="Enter surname" required>  
			<label>Gender : </label>
			<input type="radio" name="gender" value="Male">
			<label >Male</label>   
			<input type="radio" name="gender" value="Female">
			<label >Female</label><br>
	   	<label>Create password</label>
	    <input type="password" class="form-control" name="password" placeholder="Create password" required>
	    <label>Email</label>
	    <input type="email" class="form-control" name="email" placeholder="Enter email" required>
	    <label>Mobile Number </label>
	    <input type="number" class="form-control" name="mobile" placeholder="Enter mobile number" required>
	    <label>Date of birth</label>
	    <input type="date" class="form-control" name="DOB" placeholder="Enter DOB" required>
	    <label>Qualification </label>
	    <select class="form-control" name="qualification" required>
	    	<option>SSC</option>
	    	<option>HSC</option>
	    	<option>BCA</option>
	    	<option>Bsc.IT</option>
	    	<option>MCA</option>
	    	<option>B-tech</option>
	    	<option>Msc.IT</option>
	    	<option>M-tech</option>
	    	<option>B-com</option>
	    	<option>M-com</option>
	    	<option>BA</option>
	    	<option>MA</option>
	    	<option>Bsc.cs</option>
	    	<option>Msc.cs</option>
	    	<option>VFX</option>
	    	<option>Phd</option>
	    	<option>Optometry</option>
	    	<option>Bsc</option>
	    	<option>Msc</option>
	    </select>
	    <label>University</label>
	    <input type="text" class="form-control" name="university" placeholder="Enter university name" required>
	    <label>Current Address</label>
	    <textarea class="form-control" name="address" cols="9" rows="4" required></textarea><br>
	    <span>Select your profile picture :</span><br>
	    <input type="file" name="image" class="form-control" required>
		</div>
	    <span>Already have account?<a href="logIn.php">LogIn here</a></span>
  		<button type="submit" name="register" class="btn btn-success">Registeration</button>
		</form>

	</div>
</body>
</html>