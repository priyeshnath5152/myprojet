<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db_name = "testskill";

$conn = mysqli_connect($hostname,$username,$password);
mysqli_select_db($conn,$db_name);
if (!$conn) {
	die("Connection failed ".mysqli_connect_error());
}

?>