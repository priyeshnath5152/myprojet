<?php session_start();
require_once('connection.php');

	// Fetch all data in input
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$query = "select * from student where id=$id";
		$result = mysqli_query($conn,$query);

		if(count(array($result))==1) {
			$row = mysqli_fetch_array($result);
			$name = $row['name'];
			$middlename = $row['middlename'];
			$sname = $row['sname'];
			$gender = $row['gender'];
			$password = $row['password'];
			$email = $row['email'];
			$mobile = $row['mobile'];
			$DOB = $row['DOB'];
			$qualification = $row['qualification'];
			$university = $row['University'];
			$address = $row['Address'];
			$image = $row['image'];
		}
	}
	// Update Data
	if (isset($_POST['update'])){
		$id = $_GET['edit'];
		$name = $_POST['name'];
		$middlename = $_POST['middlename'];
		$sname = $_POST['sname'];
		$gender = $_POST['gender'];
		$password = $_POST['password'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
		$DOB = $_POST['DOB'];
		$qualification = $_POST['qualification'];
		$university = $_POST['university'];
		$address = $_POST['address'];
		$image=$_FILES['image']['name'];
		$temp_name=$_FILES['image']['tmp_name'];
		move_uploaded_file($temp_name,"Images/".$image);

		$update = "update student set name='$name', middlename='$middlename', sname='$sname', gender='$gender', email='$email', mobile='$mobile', DOB='$DOB', qualification='$qualification', University='$university', Address='$address', image='$image' where id='$id'";
		$result = mysqli_query($conn, $update);

		if($result){
			echo "<script>alert('Data successfuly Updated');
						location.href='home.php'</script>"; 
		}else{
			echo "<script>alert('Data Not Updated');</script>";
		}
	}
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Upadte page</title>
	<!--CDN links-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="text-success">Update Your Form</h1>
        <form class="col-8 col-sm-8 col-lg-8" action="" method="POST" enctype="multipart/form-data">
	    <label>First Name</label>
	    <input type="text" class="form-control" name="name" value="<?php echo $name; ?>">
	    <label>Middle Name</label>
	    <input type="text" class="form-control" name="middlename" value="<?php echo $middlename; ?>">
	    <label>Last Name</label>
	    <input type="text" class="form-control" name="sname" value="<?php echo $sname; ?>">  
		<label>Gender : </label>
		<input type="radio" name="gender" value="Male" <?php if($row['gender']=='Male') {echo "checked";}?>/>
		<label >Male</label>   
		<input type="radio" name="gender" value="Female" <?php if($row['gender']=='Female') {echo "checked";}?>/>
		<label >Female</label><br>
	   	<label>Create password</label>
	    <input type="password" class="form-control" name="password" value="<?php echo $password; ?>">
	    <label>Email</label>
	    <input type="email" class="form-control" name="email" value="<?php echo $email; ?>">
	    <label>Mobile Number </label>
	    <input type="number" class="form-control" name="mobile" value="<?php echo $mobile; ?>">
	    <label>Date of birth</label>
	    <input type="date" class="form-control" name="DOB" value="<?php echo $DOB; ?>">
	    <label>Qualification </label>
	    <select class="form-control" id="qualification" name="qualification">
	    	<option><?php echo $qualification; ?></option>
	    	<option>SSC</option>
	    	<option>HSC</option>
	    	<option>BCA</option>
	    	<option>Bsc.IT</option>
	    	<option>MCA</option>
	    	<option>B-tech</option>
	    	<option>Msc.IT</option>
	    	<option>M-tech</option>
	    	<option>B-com</option>
	    	<option>M-com</option>
	    	<option>BA</option>
	    	<option>MA</option>
	    	<option>Bsc.cs</option>
	    	<option>Msc.cs</option>
	    	<option>VFX</option>
	    	<option>Phd</option>
	    	<option>Optometry</option>
	    	<option>Bsc</option>
	    	<option>Msc</option>
	    </select>
	    <label>University</label>
	    <input type="text" class="form-control" name="university" value="<?php echo $university; ?>">
	    <label>Current Address</label>
	    <textarea class="form-control" name="address" cols="9" rows="4"><?php echo $address; ?></textarea><br>
	    <span>Select your profile picture :</span><br>
	    <input type="file" name="image" class="form-control" required>
		<input type="submit" class="btn btn-success mt-3" name="update" value="UPDATE DATA">
		</form>
        </div>
   

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>