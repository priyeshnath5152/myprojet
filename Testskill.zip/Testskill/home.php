<?php
session_start();
require_once('connection.php');
	
if ($_SESSION['is_login']) {
	// keep user on page
	$_SESSION['email'];
}else{
	// redirect on login page
	header("Location:logIn.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>home page</title>
	<!--CDN links-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="form-group">
	<h1>welcome <?php echo $_SESSION['email'];?> <a href='Logout.php' class='btn btn-success'>Logout</a></h1>

	</div>
	<?php
	// Delete Data
	if (isset($_GET['delete'])){
		$id = $_GET['delete'];
		$query = "delete from student where id = $id";
		$result = mysqli_query($conn,$query);
		if ($result){
		?>
		<div class="alert alert-danger" id="alert" role="alert">1 Row Deleted</div>
		<?php
		}
	}
	// Retrive Data 
	$sql = "select * from student";
	$result = mysqli_query($conn, $sql);
	echo"<table class='table table-striped'>";
		  echo"<thead>";
		   echo"<tr>";
		  echo"<th scope='col'>ID</th>";
		     echo"<th scope='col'>Name</th>";
		     echo"<th scope='col'>MiddleName</th>";
		     echo"<th scope='col'>Sname</th>";
		     echo"<th scope='col'>Gender</th>";
		     echo"<th scope='col'>Email</th>";
		     echo"<th scope='col'>Mobile</th>";
		     echo"<th scope='col'>DOM</th>";
		     echo"<th scope='col'>Qualification</th>";
		     echo"<th scope='col'>University</th>";
		     echo"<th scope='col'>Address</th>";
		     echo"<th scope='col'>Password</th>";
		     echo"<th scope='col'>Image</th>";
		     echo"<th scope='col'>Update</th>";
		     echo"<th scope='col'>Delete</th>";
		   echo"</tr>";
		 echo"</thead>";
		 while($fetch = mysqli_fetch_array($result)){
		 echo"<tbody>";
		    echo"<tr>";
		     echo"<td scope='row'>$fetch[Id]</td>";
		     echo"<td>$fetch[name]</td>";
		     echo"<td>$fetch[middlename]</td>";
		     echo"<td>$fetch[sname]</td>";
		     echo"<td>$fetch[gender]</td>";
		     echo"<td>$fetch[email]</td>";
		     echo"<td>$fetch[mobile]</td>";
		     echo"<td>$fetch[DOB]</td>";
		     echo"<td>$fetch[qualification]</td>";
		     echo"<td>$fetch[University]</td>";
		     echo"<td>$fetch[Address]</td>";
		     echo"<td>$fetch[password]</td>";
		     echo"<td><img class='img-circle' style='width:100px; height:100px;' src='Images/$fetch[image]'></td>";
		     ?>
		     <td><a href="Update.php?edit=<?php echo $fetch['Id'];?>" class="btn btn-info">Edit</a></td>
		    <td><a href="home.php?delete=<?php echo $fetch['Id'];?>" class="btn btn-danger">Delete</a></td>
			 <?php
		  echo"</tr>";
		}
		echo"</tbody>";
		echo"</table>";
	?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript"> 
        setTimeout(function () { 
            // Closing the alert 
            $('#alert').alert('close'); 
        }, 3000); 
    </script>
</body>
</html>